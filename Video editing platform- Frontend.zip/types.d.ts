// Scene represents a segment of the video timeline
interface Scene {
  id: string
  name: string
  startTime: number
  endTime: number
}

// Subtitle represents text overlay with timing
interface Subtitle {
  id: string
  text: string
  startTime: number
  endTime: number
  fontFamily: string
  fontSize: number
  color: string
  position: "top" | "middle" | "bottom"
  alignment: "left" | "center" | "right"
}

// AudioTrack represents an audio layer
interface AudioTrack {
  id: string
  name: string
  url: string
  startTime: number
  endTime: number
  volume: number
  isMuted: boolean
}

// ImageOverlay represents an image placed over the video
interface ImageOverlay {
  id: string
  type: "image"
  name: string
  url: string
  position: {
    x: number
    y: number
  }
  size: {
    width: number
    height: number
  }
  opacity: number
  rotation: number
  border: {
    width: number
    style: string
    color: string
  } | null
}
