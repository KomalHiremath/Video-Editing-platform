"use client"

import type React from "react"

import { useState, useEffect, useCallback } from "react"
import { createFFmpeg, fetchFile } from "@ffmpeg/ffmpeg"

// Initialize FFmpeg
const ffmpeg = createFFmpeg({
  log: true,
  corePath: "https://unpkg.com/@ffmpeg/core@0.11.0/dist/ffmpeg-core.js",
})

let ffmpegLoaded = false

export function useVideoEditor() {
  const [videoFile, setVideoFile] = useState<File | null>(null)
  const [videoUrl, setVideoUrl] = useState<string>("")
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [duration, setDuration] = useState(0)
  const [trimStart, setTrimStart] = useState(0)
  const [trimEnd, setTrimEnd] = useState(0)
  const [isProcessing, setIsProcessing] = useState(false)

  // Load FFmpeg
  useEffect(() => {
    const load = async () => {
      if (!ffmpegLoaded) {
        await ffmpeg.load()
        ffmpegLoaded = true
      }
    }
    load()
  }, [])

  const handleFileChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setVideoFile(file)
      const url = URL.createObjectURL(file)
      setVideoUrl(url)

      // Reset state
      setCurrentTime(0)
      setIsPlaying(false)

      // Get video duration
      const video = document.createElement("video")
      video.src = url
      video.onloadedmetadata = () => {
        setDuration(video.duration)
        setTrimStart(0)
        setTrimEnd(video.duration)
      }
    }
  }, [])

  const handlePlayPause = useCallback(() => {
    setIsPlaying((prev) => !prev)
  }, [])

  const handleTimeUpdate = useCallback((time: number) => {
    setCurrentTime(time)
  }, [])

  const handleTrimChange = useCallback((values: number[]) => {
    setTrimStart(values[0])
    setTrimEnd(values[1])
  }, [])

  const handleSeek = useCallback(
    (time: number) => {
      const newTime = Math.max(0, Math.min(time, duration))
      setCurrentTime(newTime)
    },
    [duration],
  )

  const handleCut = useCallback(async () => {
    if (!videoFile || !ffmpegLoaded) return

    setIsProcessing(true)

    try {
      // Write the input file to memory
      ffmpeg.FS("writeFile", "input.mp4", await fetchFile(videoFile))

      // Run the FFmpeg command
      await ffmpeg.run(
        "-i",
        "input.mp4",
        "-ss",
        trimStart.toString(),
        "-to",
        trimEnd.toString(),
        "-c",
        "copy",
        "output.mp4",
      )

      // Read the result
      const data = ffmpeg.FS("readFile", "output.mp4")

      // Create a URL
      const blob = new Blob([data.buffer], { type: "video/mp4" })
      const url = URL.createObjectURL(blob)

      // Update the video
      setVideoUrl(url)
      setVideoFile(new File([blob], "trimmed.mp4", { type: "video/mp4" }))

      // Reset playback
      setCurrentTime(0)
      setIsPlaying(false)

      // Get new duration
      const video = document.createElement("video")
      video.src = url
      video.onloadedmetadata = () => {
        setDuration(video.duration)
        setTrimStart(0)
        setTrimEnd(video.duration)
      }
    } catch (error) {
      console.error("Error processing video:", error)
    } finally {
      setIsProcessing(false)
    }
  }, [videoFile, trimStart, trimEnd])

  const handleExport = useCallback(async () => {
    if (!videoFile) return

    // If we're already using the trimmed version, just download it
    const a = document.createElement("a")
    a.href = videoUrl
    a.download = "edited_video.mp4"
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
  }, [videoFile, videoUrl])

  return {
    videoFile,
    videoUrl,
    isPlaying,
    currentTime,
    duration,
    trimStart,
    trimEnd,
    isProcessing,
    handleFileChange,
    handlePlayPause,
    handleTimeUpdate,
    handleTrimChange,
    handleSeek,
    handleCut,
    handleExport,
  }
}
