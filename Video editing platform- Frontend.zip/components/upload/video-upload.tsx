"use client"

import { Button } from "@/components/ui/button"

import { useState, useCallback } from "react"
import { useDropzone } from "react-dropzone"
import { Upload, FileVideo } from "lucide-react"
import { Progress } from "@/components/ui/progress"
import { useAppDispatch } from "@/lib/redux/hooks"
import { setVideoUrl, setVideoDuration } from "@/lib/redux/slices/projectSlice"
import { addScenes } from "@/lib/redux/slices/timelineSlice"
import { mockUploadVideo } from "@/lib/utils/mock-api"

export default function VideoUpload() {
  const dispatch = useAppDispatch()
  const [uploadProgress, setUploadProgress] = useState(0)
  const [isUploading, setIsUploading] = useState(false)

  const onDrop = useCallback(
    async (acceptedFiles: File[]) => {
      const file = acceptedFiles[0]
      if (!file) return

      setIsUploading(true)
      setUploadProgress(0)

      try {
        // Create a local URL for the video
        const videoUrl = URL.createObjectURL(file)

        // Simulate upload progress
        const { progress } = await mockUploadVideo(file, (progress) => {
          setUploadProgress(progress)
        })

        // Get video duration
        const video = document.createElement("video")
        video.src = videoUrl

        video.onloadedmetadata = () => {
          const duration = video.duration

          // Update Redux store with video info
          dispatch(setVideoUrl(videoUrl))
          dispatch(setVideoDuration(duration))

          // Create initial scene that spans the entire video
          dispatch(
            addScenes([
              {
                id: "scene-1",
                startTime: 0,
                endTime: duration,
                name: "Main Scene",
              },
            ]),
          )

          setIsUploading(false)
        }

        video.onerror = () => {
          console.error("Error loading video")
          setIsUploading(false)
        }
      } catch (error) {
        console.error("Error uploading video:", error)
        setIsUploading(false)
      }
    },
    [dispatch],
  )

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      "video/*": [".mp4", ".webm", ".mov", ".avi"],
    },
    maxFiles: 1,
    disabled: isUploading,
  })

  return (
    <div className="flex flex-col items-center justify-center h-[60vh] border-2 border-dashed rounded-lg p-12">
      {isUploading ? (
        <div className="w-full max-w-md space-y-4">
          <div className="flex items-center justify-center">
            <FileVideo className="h-12 w-12 text-gray-400 mb-4" />
          </div>
          <h3 className="text-xl font-semibold text-center">Uploading video...</h3>
          <Progress value={uploadProgress} className="w-full" />
          <p className="text-center text-gray-500">{Math.round(uploadProgress)}% complete</p>
        </div>
      ) : (
        <div
          {...getRootProps()}
          className={`flex flex-col items-center justify-center w-full h-full cursor-pointer ${
            isDragActive ? "bg-gray-100 dark:bg-gray-800" : ""
          }`}
        >
          <input {...getInputProps()} />
          <Upload className="h-12 w-12 text-gray-400 mb-4" />
          <h2 className="text-xl font-semibold mb-2">Drag & drop your video here</h2>
          <p className="text-gray-500 mb-4 text-center max-w-md">Supported formats: MP4, WebM, MOV, AVI (max 500MB)</p>
          <Button>Select Video</Button>
        </div>
      )}
    </div>
  )
}
