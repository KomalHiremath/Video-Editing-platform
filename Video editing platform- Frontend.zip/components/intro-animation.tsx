"use client"

import { useState, useEffect } from "react"
import { Progress } from "@/components/ui/progress"
import dynamic from "next/dynamic"
import { Video } from "lucide-react"

// Import Spline component with no SSR
const Spline = dynamic(() => import("@splinetool/react-spline").then((mod) => mod.default), {
  ssr: false,
  loading: () => null,
})

export default function IntroAnimation({ onComplete }: { onComplete: () => void }) {
  const [loadingProgress, setLoadingProgress] = useState(0)
  const [isLoaded, setIsLoaded] = useState(false)
  const [isZoomingOut, setIsZoomingOut] = useState(false)
  const [showSpline, setShowSpline] = useState(false)
  const [loadError, setLoadError] = useState(false)

  // Simulate loading progress
  useEffect(() => {
    const interval = setInterval(() => {
      setLoadingProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setIsLoaded(true)
          setShowSpline(true)
          return 100
        }
        return prev + 2
      })
    }, 50)

    return () => clearInterval(interval)
  }, [])

  // Start zoom out animation after loading completes
  useEffect(() => {
    if (isLoaded) {
      const timer = setTimeout(() => {
        setIsZoomingOut(true)
      }, 1000)

      return () => clearTimeout(timer)
    }
  }, [isLoaded])

  // Complete intro after zoom out animation
  useEffect(() => {
    if (isZoomingOut || loadError) {
      const timer = setTimeout(() => {
        onComplete()
      }, 1500)

      return () => clearTimeout(timer)
    }
  }, [isZoomingOut, loadError, onComplete])

  const handleSplineError = () => {
    setLoadError(true)
    setIsLoaded(true)
  }

  return (
    <div
      className={`fixed inset-0 z-50 bg-black transition-all duration-1500 ${
        isZoomingOut ? "scale-150 opacity-0" : "scale-100 opacity-100"
      }`}
    >
      <div className="relative w-full h-full">
        {/* Spline animation */}
        <div className="w-full h-full">
          {showSpline && !loadError && (
            <Spline scene="https://prod.spline.design/6Wq1Q7YGyM-iab9i/scene.splinecode" onError={handleSplineError} />
          )}
          {loadError && (
            <div className="w-full h-full flex items-center justify-center">
              <Video className="h-24 w-24 text-white opacity-30" />
            </div>
          )}
        </div>

        {/* Loading overlay */}
        {!isLoaded && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-black bg-opacity-70">
            <h1 className="text-4xl font-bold text-white mb-8">MOVE 37 PRODUCTION</h1>
            <div className="w-64 mb-4">
              <Progress value={loadingProgress} className="h-3" />
            </div>
            <p className="text-white">{loadingProgress}%</p>
          </div>
        )}

        {/* Branding overlay that stays during zoom */}
        {isLoaded && !isZoomingOut && (
          <div className="absolute inset-0 flex items-center justify-center">
            <h1 className="text-5xl font-bold text-white animate-pulse">MOVE 37 PRODUCTION</h1>
          </div>
        )}
      </div>
    </div>
  )
}
