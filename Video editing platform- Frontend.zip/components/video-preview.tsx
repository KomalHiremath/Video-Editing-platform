"use client"

import { useRef, useEffect } from "react"

interface VideoPreviewProps {
  videoUrl: string
  isPlaying: boolean
  currentTime: number
  onTimeUpdate: (time: number) => void
  onPlayPause: () => void
}

export default function VideoPreview({
  videoUrl,
  isPlaying,
  currentTime,
  onTimeUpdate,
  onPlayPause,
}: VideoPreviewProps) {
  const videoRef = useRef<HTMLVideoElement>(null)

  useEffect(() => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.play().catch((error) => {
          console.error("Error playing video:", error)
        })
      } else {
        videoRef.current.pause()
      }
    }
  }, [isPlaying])

  useEffect(() => {
    if (videoRef.current && Math.abs(videoRef.current.currentTime - currentTime) > 0.5) {
      videoRef.current.currentTime = currentTime
    }
  }, [currentTime])

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      onTimeUpdate(videoRef.current.currentTime)
    }
  }

  return (
    <div className="relative aspect-video bg-black rounded-lg overflow-hidden">
      <video
        ref={videoRef}
        src={videoUrl}
        className="w-full h-full"
        onClick={onPlayPause}
        onTimeUpdate={handleTimeUpdate}
        onEnded={() => onPlayPause()}
      />
    </div>
  )
}
