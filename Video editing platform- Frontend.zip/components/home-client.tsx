"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Video, ArrowRight, Info } from "lucide-react"
import SplinePreview from "@/components/spline-preview"
import IntroAnimation from "@/components/intro-animation"
import UserGuidance from "@/components/user-guidance"
import { ThemeSwitcher } from "@/components/theme-switcher"

export default function HomeClient() {
  const [showIntro, setShowIntro] = useState(true)
  const [showGuidance, setShowGuidance] = useState(false)
  const [isFirstVisit, setIsFirstVisit] = useState(true)

  // Check if this is the first visit
  useEffect(() => {
    const hasVisited = localStorage.getItem("hasVisitedBefore")
    if (hasVisited) {
      setShowIntro(false)
      setIsFirstVisit(false)
    } else {
      // Set flag for future visits
      localStorage.setItem("hasVisitedBefore", "true")
    }
  }, [])

  const handleIntroComplete = () => {
    setShowIntro(false)
    // Show guidance after a short delay
    setTimeout(() => {
      setShowGuidance(true)
    }, 500)
  }

  return (
    <>
      {showIntro && <IntroAnimation onComplete={handleIntroComplete} />}

      <div className="flex flex-col min-h-screen">
        <header className="border-b">
          <div className="container flex h-16 items-center px-4 md:px-6">
            <Link href="/" className="flex items-center gap-2 font-semibold">
              <Video className="h-6 w-6" />
              <span>MOVE 37 PRODUCTION</span>
            </Link>
            <nav className="ml-auto flex gap-4 sm:gap-6">
              <Link href="/editor" className="text-sm font-medium hover:underline underline-offset-4">
                Editor
              </Link>
              <Link href="#" className="text-sm font-medium hover:underline underline-offset-4">
                Templates
              </Link>
              <Link href="#" className="text-sm font-medium hover:underline underline-offset-4">
                Pricing
              </Link>
              <ThemeSwitcher />
            </nav>
          </div>
        </header>
        <main className="flex-1">
          <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-white to-gray-100 dark:from-gray-900 dark:to-gray-800">
            <div className="container px-4 md:px-6">
              <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 xl:grid-cols-2">
                <div className="flex flex-col justify-center space-y-4">
                  <div className="space-y-2">
                    <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none">
                      Professional Video Editing in Your Browser
                    </h1>
                    <p className="max-w-[600px] text-gray-500 md:text-xl dark:text-gray-400">
                      Edit, enhance, and export high-quality videos without installing any software. Powerful tools for
                      creators of all skill levels.
                    </p>
                  </div>
                  <div className="flex flex-col gap-2 min-[400px]:flex-row">
                    <Link href="/editor">
                      <Button size="lg" className="h-12 px-8">
                        Start Editing <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                    {isFirstVisit && (
                      <Button variant="outline" size="lg" className="h-12 px-8" onClick={() => setShowGuidance(true)}>
                        <Info className="mr-2 h-4 w-4" /> How It Works
                      </Button>
                    )}
                  </div>
                </div>
                <div className="mx-auto aspect-video overflow-hidden rounded-xl border bg-gray-100 dark:bg-gray-800 object-cover">
                  <SplinePreview />
                </div>
              </div>
            </div>
          </section>
          <section className="w-full py-12 md:py-24 lg:py-32">
            <div className="container px-4 md:px-6">
              <div className="flex flex-col items-center justify-center space-y-4 text-center">
                <div className="space-y-2">
                  <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Powerful Features</h2>
                  <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl dark:text-gray-400">
                    Everything you need to create stunning videos in one place.
                  </p>
                </div>
              </div>
              <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 py-12 md:grid-cols-3">
                <div className="flex flex-col items-center space-y-2 rounded-lg border p-6 shadow-sm">
                  <div className="rounded-full bg-gray-100 p-3 dark:bg-gray-800">
                    <svg
                      className="h-6 w-6"
                      fill="none"
                      height="24"
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      viewBox="0 0 24 24"
                      width="24"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path d="M4 10h12" />
                      <path d="M4 14h9" />
                      <path d="M19 6a7.7 7.7 0 0 0-5.2-2A7.9 7.9 0 0 0 6 12c0 4.4 3.5 8 8 8 2 0 3.8-.8 5.2-2" />
                    </svg>
                  </div>
                  <h3 className="text-xl font-bold">Timeline Editing</h3>
                  <p className="text-center text-gray-500 dark:text-gray-400">
                    Intuitive timeline interface for precise control over your video edits.
                  </p>
                </div>
                <div className="flex flex-col items-center space-y-2 rounded-lg border p-6 shadow-sm">
                  <div className="rounded-full bg-gray-100 p-3 dark:bg-gray-800">
                    <svg
                      className="h-6 w-6"
                      fill="none"
                      height="24"
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      viewBox="0 0 24 24"
                      width="24"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path d="M12 20h9" />
                      <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z" />
                    </svg>
                  </div>
                  <h3 className="text-xl font-bold">Text & Subtitles</h3>
                  <p className="text-center text-gray-500 dark:text-gray-400">
                    Add professional text overlays and subtitles with custom styling.
                  </p>
                </div>
                <div className="flex flex-col items-center space-y-2 rounded-lg border p-6 shadow-sm">
                  <div className="rounded-full bg-gray-100 p-3 dark:bg-gray-800">
                    <svg
                      className="h-6 w-6"
                      fill="none"
                      height="24"
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      viewBox="0 0 24 24"
                      width="24"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path d="M3 18v-6a9 9 0 0 1 18 0v6" />
                      <path d="M21 19a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3zM3 19a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z" />
                    </svg>
                  </div>
                  <h3 className="text-xl font-bold">Audio Management</h3>
                  <p className="text-center text-gray-500 dark:text-gray-400">
                    Control audio tracks, add background music, and adjust levels.
                  </p>
                </div>
              </div>
            </div>
          </section>
        </main>
        <footer className="border-t py-6 md:py-0">
          <div className="container flex flex-col items-center justify-between gap-4 md:h-16 md:flex-row">
            <p className="text-center text-sm leading-loose text-gray-500 md:text-left">
              © 2023 MOVE 37 PRODUCTION. All rights reserved.
            </p>
            <div className="flex gap-4">
              <Link href="#" className="text-sm font-medium hover:underline underline-offset-4">
                Terms
              </Link>
              <Link href="#" className="text-sm font-medium hover:underline underline-offset-4">
                Privacy
              </Link>
            </div>
          </div>
        </footer>
      </div>

      {/* User guidance tour */}
      {showGuidance && <UserGuidance onClose={() => setShowGuidance(false)} />}
    </>
  )
}
