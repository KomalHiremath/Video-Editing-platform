"use client"
import { Sliders, Crop, RotateCw, Palette, RefreshCw } from "lucide-react"
import { Slider } from "@/components/ui/slider"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { useAppSelector, useAppDispatch } from "@/lib/redux/hooks"
import { selectProject, updateVideoSettings, applyFilter } from "@/lib/redux/slices/projectSlice"

export default function ControlPanel() {
  const dispatch = useAppDispatch()
  const { videoSettings } = useAppSelector(selectProject)

  const handleSettingChange = (setting: string, value: number) => {
    dispatch(updateVideoSettings({ [setting]: value }))
  }

  const handleRotate90 = () => {
    // Add 90 degrees to current rotation, keeping it within 0-360
    const newRotation = (videoSettings.rotation + 90) % 360
    dispatch(updateVideoSettings({ rotation: newRotation }))
  }

  const handleFlipHorizontal = () => {
    // Toggle the horizontal flip setting
    dispatch(
      updateVideoSettings({
        flipHorizontal: !videoSettings.flipHorizontal,
      }),
    )
  }

  const handleApplyFilter = (filterName: string) => {
    dispatch(applyFilter(filterName))
  }

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold">Video Settings</h3>

      <Accordion type="single" collapsible className="w-full">
        <AccordionItem value="adjustments">
          <AccordionTrigger className="flex items-center">
            <Sliders className="h-4 w-4 mr-2" />
            <span>Adjustments</span>
          </AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4 pt-2">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <Label htmlFor="brightness">Brightness</Label>
                  <span className="text-xs text-gray-500">{videoSettings.brightness}%</span>
                </div>
                <Slider
                  id="brightness"
                  min={0}
                  max={200}
                  step={1}
                  value={[videoSettings.brightness]}
                  onValueChange={(value) => handleSettingChange("brightness", value[0])}
                />
              </div>

              <div className="space-y-2">
                <div className="flex justify-between">
                  <Label htmlFor="contrast">Contrast</Label>
                  <span className="text-xs text-gray-500">{videoSettings.contrast}%</span>
                </div>
                <Slider
                  id="contrast"
                  min={0}
                  max={200}
                  step={1}
                  value={[videoSettings.contrast]}
                  onValueChange={(value) => handleSettingChange("contrast", value[0])}
                />
              </div>

              <div className="space-y-2">
                <div className="flex justify-between">
                  <Label htmlFor="saturation">Saturation</Label>
                  <span className="text-xs text-gray-500">{videoSettings.saturation}%</span>
                </div>
                <Slider
                  id="saturation"
                  min={0}
                  max={200}
                  step={1}
                  value={[videoSettings.saturation]}
                  onValueChange={(value) => handleSettingChange("saturation", value[0])}
                />
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="crop">
          <AccordionTrigger className="flex items-center">
            <Crop className="h-4 w-4 mr-2" />
            <span>Crop & Rotate</span>
          </AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4 pt-2">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <Label htmlFor="rotation">Rotation</Label>
                  <span className="text-xs text-gray-500">{videoSettings.rotation}°</span>
                </div>
                <Slider
                  id="rotation"
                  min={0}
                  max={360}
                  step={1}
                  value={[videoSettings.rotation]}
                  onValueChange={(value) => handleSettingChange("rotation", value[0])}
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <Button variant="outline" size="sm" onClick={handleRotate90}>
                  <RotateCw className="h-4 w-4 mr-1" /> Rotate 90°
                </Button>
                <Button
                  variant={videoSettings.flipHorizontal ? "default" : "outline"}
                  size="sm"
                  onClick={handleFlipHorizontal}
                >
                  <RefreshCw className="h-4 w-4 mr-1" /> Flip Horizontal
                </Button>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="filters">
          <AccordionTrigger className="flex items-center">
            <Palette className="h-4 w-4 mr-2" />
            <span>Filters</span>
          </AccordionTrigger>
          <AccordionContent>
            <div className="grid grid-cols-3 gap-2 pt-2">
              <Button
                variant={videoSettings.filter === "none" ? "default" : "outline"}
                size="sm"
                className="h-20 flex flex-col"
                onClick={() => handleApplyFilter("none")}
              >
                <div className="w-full h-12 bg-gray-200 rounded mb-1"></div>
                <span className="text-xs">None</span>
              </Button>
              <Button
                variant={videoSettings.filter === "sepia" ? "default" : "outline"}
                size="sm"
                className="h-20 flex flex-col"
                onClick={() => handleApplyFilter("sepia")}
              >
                <div className="w-full h-12 bg-gray-200 rounded mb-1 sepia"></div>
                <span className="text-xs">Sepia</span>
              </Button>
              <Button
                variant={videoSettings.filter === "grayscale" ? "default" : "outline"}
                size="sm"
                className="h-20 flex flex-col"
                onClick={() => handleApplyFilter("grayscale")}
              >
                <div className="w-full h-12 bg-gray-200 rounded mb-1 grayscale"></div>
                <span className="text-xs">B&W</span>
              </Button>
              <Button
                variant={videoSettings.filter === "bright" ? "default" : "outline"}
                size="sm"
                className="h-20 flex flex-col"
                onClick={() => handleApplyFilter("bright")}
              >
                <div className="w-full h-12 bg-gray-200 rounded mb-1 brightness-125"></div>
                <span className="text-xs">Bright</span>
              </Button>
              <Button
                variant={videoSettings.filter === "vivid" ? "default" : "outline"}
                size="sm"
                className="h-20 flex flex-col"
                onClick={() => handleApplyFilter("vivid")}
              >
                <div className="w-full h-12 bg-gray-200 rounded mb-1 contrast-125"></div>
                <span className="text-xs">Vivid</span>
              </Button>
              <Button
                variant={videoSettings.filter === "cool" ? "default" : "outline"}
                size="sm"
                className="h-20 flex flex-col"
                onClick={() => handleApplyFilter("cool")}
              >
                <div className="w-full h-12 bg-gray-200 rounded mb-1 hue-rotate-90"></div>
                <span className="text-xs">Cool</span>
              </Button>
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </div>
  )
}
