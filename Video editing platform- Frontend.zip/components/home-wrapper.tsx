"use client"

import type React from "react"

import { usePathname } from "next/navigation"
import dynamic from "next/dynamic"

// Import Spline component with no SSR
const Spline = dynamic(() => import("@splinetool/react-spline").then((mod) => mod.default), {
  ssr: false,
  loading: () => null,
})

export default function HomeWrapper({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()
  const isHomePage = pathname === "/"

  return (
    <>
      {children}
      {isHomePage && (
        <main>
          <Spline scene="https://prod.spline.design/IrO0BX83tx5flkxe/scene.splinecode" width={4096} height={2737} />
        </main>
      )}
    </>
  )
}
