"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { ChevronLeft, ChevronRight, X, Video, Scissors, Music, Type, ImageIcon, Download } from "lucide-react"

interface Step {
  title: string
  description: string
  icon: React.ReactNode
  position: string
}

export default function UserGuidance({ onClose }: { onClose: () => void }) {
  const [currentStep, setCurrentStep] = useState(0)

  const steps: Step[] = [
    {
      title: "Welcome to MOVE 37 PRODUCTION",
      description:
        "Our browser-based video editor gives you professional tools without the need to install any software. Let's take a quick tour!",
      icon: <Video className="h-12 w-12" />,
      position: "center",
    },
    {
      title: "Upload Your Videos",
      description:
        "Start by uploading your video files. Our editor supports most common formats including MP4, WebM, and MOV.",
      icon: <Video className="h-12 w-12" />,
      position: "top-left",
    },
    {
      title: "Timeline Editing",
      description:
        "Use our intuitive timeline to trim, split, and rearrange scenes. Drag and drop to reorder clips and create the perfect sequence.",
      icon: <Scissors className="h-12 w-12" />,
      position: "bottom",
    },
    {
      title: "Add Audio Tracks",
      description:
        "Enhance your videos with background music, sound effects, or voiceovers. Adjust volume levels and timing for each audio track.",
      icon: <Music className="h-12 w-12" />,
      position: "right",
    },
    {
      title: "Text and Subtitles",
      description:
        "Add professional text overlays and subtitles. Customize fonts, colors, and animations to make your message stand out.",
      icon: <Type className="h-12 w-12" />,
      position: "left",
    },
    {
      title: "Image Overlays",
      description:
        "Insert logos, stickers, or other images. Position them precisely and adjust opacity, size, and rotation as needed.",
      icon: <ImageIcon className="h-12 w-12" />,
      position: "top-right",
    },
    {
      title: "Export Your Masterpiece",
      description:
        "When you're finished editing, export your video in various formats and quality settings. Share directly or download to your device.",
      icon: <Download className="h-12 w-12" />,
      position: "bottom-right",
    },
  ]

  const getPositionClass = (position: string) => {
    switch (position) {
      case "top-left":
        return "top-24 left-24"
      case "top-right":
        return "top-24 right-24"
      case "bottom-left":
        return "bottom-24 left-24"
      case "bottom-right":
        return "bottom-24 right-24"
      case "top":
        return "top-24 left-1/2 -translate-x-1/2"
      case "bottom":
        return "bottom-24 left-1/2 -translate-x-1/2"
      case "left":
        return "left-24 top-1/2 -translate-y-1/2"
      case "right":
        return "right-24 top-1/2 -translate-y-1/2"
      default:
        return "top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"
    }
  }

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1)
    } else {
      onClose()
    }
  }

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
    }
  }

  const currentStepData = steps[currentStep]

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
      <div className={`absolute ${getPositionClass(currentStepData.position)} transition-all duration-500`}>
        <Card className="w-[450px] shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-xl">{currentStepData.title}</CardTitle>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </CardHeader>
          <CardContent className="flex flex-col items-center text-center gap-4 pb-2">
            <div className="rounded-full bg-primary/10 p-6">{currentStepData.icon}</div>
            <p>{currentStepData.description}</p>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button variant="outline" onClick={handlePrevious} disabled={currentStep === 0}>
              <ChevronLeft className="mr-2 h-4 w-4" /> Previous
            </Button>
            <div className="flex items-center gap-1">
              {steps.map((_, index) => (
                <div
                  key={index}
                  className={`h-2 w-2 rounded-full ${
                    index === currentStep ? "bg-primary" : "bg-gray-300 dark:bg-gray-600"
                  }`}
                />
              ))}
            </div>
            <Button onClick={handleNext}>
              {currentStep < steps.length - 1 ? (
                <>
                  Next <ChevronRight className="ml-2 h-4 w-4" />
                </>
              ) : (
                "Get Started"
              )}
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
