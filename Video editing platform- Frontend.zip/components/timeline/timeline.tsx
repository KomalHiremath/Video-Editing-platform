"use client"

import type React from "react"

import { useRef } from "react"
import { DndProvider, useDrag, useDrop } from "react-dnd"
import { HTML5Backend } from "react-dnd-html5-backend"
import { Scissors, Plus, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useAppSelector, useAppDispatch } from "@/lib/redux/hooks"
import { selectProject, setCurrentTime } from "@/lib/redux/slices/projectSlice"
import { selectScenes, addScenes, removeScene, reorderScenes, splitSceneAtTime } from "@/lib/redux/slices/timelineSlice"
import { formatTime } from "@/lib/utils/time-format"
import { cn } from "@/lib/utils"

// Define the Scene type
interface Scene {
  id: string
  startTime: number
  endTime: number
  name: string
}

// Scene item component with drag and drop
const SceneItem = ({
  scene,
  index,
  onReorder,
}: { scene: Scene; index: number; onReorder: (dragIndex: number, hoverIndex: number) => void }) => {
  const dispatch = useAppDispatch()
  const { currentTime, duration } = useAppSelector(selectProject)
  const ref = useRef<HTMLDivElement>(null)

  // Set up drag
  const [{ isDragging }, drag] = useDrag({
    type: "SCENE",
    item: { index },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  })

  // Set up drop
  const [, drop] = useDrop({
    accept: "SCENE",
    hover(item: { index: number }, monitor) {
      if (!ref.current) return

      const dragIndex = item.index
      const hoverIndex = index

      if (dragIndex === hoverIndex) return

      onReorder(dragIndex, hoverIndex)
      item.index = hoverIndex
    },
  })

  // Combine drag and drop refs
  drag(drop(ref))

  // Calculate scene width based on duration
  const sceneWidth = ((scene.endTime - scene.startTime) / duration) * 100

  // Calculate current time indicator position
  const isCurrentTimeInScene = currentTime >= scene.startTime && currentTime <= scene.endTime
  const currentTimePosition = isCurrentTimeInScene
    ? ((currentTime - scene.startTime) / (scene.endTime - scene.startTime)) * 100
    : null

  // Handle click on scene to seek
  const handleSceneClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!ref.current) return

    const rect = ref.current.getBoundingClientRect()
    const clickPosition = (e.clientX - rect.left) / rect.width
    const newTime = scene.startTime + clickPosition * (scene.endTime - scene.startTime)

    dispatch(setCurrentTime(newTime))
  }

  // Handle scene removal
  const handleRemove = (e: React.MouseEvent) => {
    e.stopPropagation()
    dispatch(removeScene(scene.id))
  }

  return (
    <div
      ref={ref}
      className={cn(
        "relative h-16 rounded-md p-2 cursor-move border-2 flex flex-col justify-between",
        isDragging ? "opacity-50 border-dashed" : "border-solid border-gray-300",
      )}
      style={{ width: `${sceneWidth}%` }}
      onClick={handleSceneClick}
    >
      <div className="flex justify-between items-start">
        <span className="text-xs font-medium truncate">{scene.name}</span>
        <Button variant="ghost" size="icon" className="h-5 w-5" onClick={handleRemove}>
          <Trash2 className="h-3 w-3" />
        </Button>
      </div>
      <div className="text-xs text-gray-500">
        {formatTime(scene.startTime)} - {formatTime(scene.endTime)}
      </div>

      {/* Current time indicator */}
      {currentTimePosition !== null && (
        <div className="absolute top-0 bottom-0 w-0.5 bg-red-500" style={{ left: `${currentTimePosition}%` }} />
      )}
    </div>
  )
}

export default function Timeline() {
  const dispatch = useAppDispatch()
  const { duration, currentTime } = useAppSelector(selectProject)
  const scenes = useAppSelector(selectScenes)

  // Handle scene reordering
  const handleReorder = (dragIndex: number, hoverIndex: number) => {
    dispatch(reorderScenes({ dragIndex, hoverIndex }))
  }

  // Handle adding a new scene
  const handleAddScene = () => {
    // Find a gap or add to the end
    let startTime = 0
    let endTime = Math.min(startTime + 10, duration)

    // Check for existing scenes to avoid overlap
    if (scenes.length > 0) {
      // Sort scenes by start time
      const sortedScenes = [...scenes].sort((a, b) => a.startTime - b.startTime)

      // Find a gap between scenes
      for (let i = 0; i < sortedScenes.length - 1; i++) {
        const gap = sortedScenes[i + 1].startTime - sortedScenes[i].endTime
        if (gap >= 2) {
          // Minimum 2 second gap
          startTime = sortedScenes[i].endTime
          endTime = Math.min(startTime + gap, sortedScenes[i + 1].startTime)
          break
        }
      }

      // If no gap found, add to the end
      if (startTime === 0) {
        const lastScene = sortedScenes[sortedScenes.length - 1]
        startTime = lastScene.endTime
        endTime = Math.min(startTime + 10, duration)
      }
    }

    // Create new scene
    dispatch(
      addScenes([
        {
          id: `scene-${Date.now()}`,
          startTime,
          endTime,
          name: `Scene ${scenes.length + 1}`,
        },
      ]),
    )
  }

  // Handle splitting a scene at the current time
  const handleSplitScene = () => {
    // Find the scene that contains the current time
    const currentScene = scenes.find((scene) => currentTime > scene.startTime && currentTime < scene.endTime)

    if (currentScene) {
      dispatch(splitSceneAtTime({ sceneId: currentScene.id, splitTime: currentTime }))
    }
  }

  // Handle timeline click to seek
  const handleTimelineClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect()
    const clickPosition = (e.clientX - rect.left) / rect.width
    const newTime = clickPosition * duration

    dispatch(setCurrentTime(newTime))
  }

  // Generate time markers
  const timeMarkers = []
  const markerCount = 10
  for (let i = 0; i <= markerCount; i++) {
    const time = (duration / markerCount) * i
    timeMarkers.push(
      <div key={i} className="absolute text-xs text-gray-500" style={{ left: `${(i / markerCount) * 100}%` }}>
        {formatTime(time)}
      </div>,
    )
  }

  // Check if we can split (if there's a scene at current time)
  const canSplit = scenes.some((scene) => currentTime > scene.startTime && currentTime < scene.endTime)

  return (
    <div className="border rounded-lg p-4 space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Timeline</h3>
        <div className="flex space-x-2">
          <Button variant="outline" size="sm" onClick={handleAddScene}>
            <Plus className="h-4 w-4 mr-1" /> Add Scene
          </Button>
          <Button variant="outline" size="sm" onClick={handleSplitScene} disabled={!canSplit}>
            <Scissors className="h-4 w-4 mr-1" /> Split
          </Button>
        </div>
      </div>

      {/* Time markers */}
      <div className="relative h-6 mb-1">{timeMarkers}</div>

      {/* Timeline track */}
      <div className="relative h-2 bg-gray-200 rounded-full mb-2 cursor-pointer" onClick={handleTimelineClick}>
        {/* Current time indicator */}
        <div
          className="absolute top-0 bottom-0 w-0.5 bg-red-500 z-10"
          style={{ left: `${(currentTime / duration) * 100}%` }}
        />

        {/* Playback progress */}
        <div
          className="absolute top-0 bottom-0 left-0 bg-blue-500 rounded-full"
          style={{ width: `${(currentTime / duration) * 100}%` }}
        />
      </div>

      {/* Scenes container */}
      <DndProvider backend={HTML5Backend}>
        <div className="flex gap-1 overflow-x-auto pb-2">
          {scenes.map((scene, index) => (
            <SceneItem key={scene.id} scene={scene} index={index} onReorder={handleReorder} />
          ))}
        </div>
      </DndProvider>
    </div>
  )
}
