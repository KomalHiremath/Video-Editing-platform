"use client"

import type React from "react"

import { useState } from "react"
import { Plus, Trash2, AlignLeft, AlignCenter, AlignRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useAppSelector, useAppDispatch } from "@/lib/redux/hooks"
import { selectSubtitles, addSubtitle, updateSubtitle, removeSubtitle } from "@/lib/redux/slices/subtitlesSlice"
import { selectProject } from "@/lib/redux/slices/projectSlice"
import { formatTime } from "@/lib/utils/time-format"
import type { Subtitle } from "@/lib/types"

export default function SubtitleEditor() {
  const dispatch = useAppDispatch()
  const subtitles = useAppSelector(selectSubtitles)
  const { currentTime, duration } = useAppSelector(selectProject)

  const [selectedSubtitleId, setSelectedSubtitleId] = useState<string | null>(null)

  // Find selected subtitle or create a new one
  const selectedSubtitle = selectedSubtitleId ? subtitles.find((sub) => sub.id === selectedSubtitleId) || null : null

  // Handle adding a new subtitle
  const handleAddSubtitle = () => {
    const newSubtitle: Subtitle = {
      id: `subtitle-${Date.now()}`,
      text: "New subtitle",
      startTime: Math.max(0, currentTime - 0.5),
      endTime: Math.min(duration, currentTime + 2.5),
      fontFamily: "Arial",
      fontSize: 24,
      color: "#FFFFFF",
      position: "bottom",
      alignment: "center",
    }

    dispatch(addSubtitle(newSubtitle))
    setSelectedSubtitleId(newSubtitle.id)
  }

  // Handle updating subtitle text
  const handleTextChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!selectedSubtitleId) return

    dispatch(
      updateSubtitle({
        id: selectedSubtitleId,
        changes: { text: e.target.value },
      }),
    )
  }

  // Handle updating subtitle timing
  const handleTimingChange = (values: number[]) => {
    if (!selectedSubtitleId) return

    dispatch(
      updateSubtitle({
        id: selectedSubtitleId,
        changes: { startTime: values[0], endTime: values[1] },
      }),
    )
  }

  // Handle updating subtitle style
  const handleStyleChange = (property: string, value: any) => {
    if (!selectedSubtitleId) return

    dispatch(
      updateSubtitle({
        id: selectedSubtitleId,
        changes: { [property]: value },
      }),
    )
  }

  // Handle removing a subtitle
  const handleRemoveSubtitle = () => {
    if (!selectedSubtitleId) return

    dispatch(removeSubtitle(selectedSubtitleId))
    setSelectedSubtitleId(null)
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Subtitles & Text</h3>
        <Button size="sm" onClick={handleAddSubtitle}>
          <Plus className="h-4 w-4 mr-1" /> Add Subtitle
        </Button>
      </div>

      {/* Subtitle list */}
      <div className="space-y-2 max-h-40 overflow-y-auto">
        {subtitles.length === 0 ? (
          <p className="text-sm text-gray-500 text-center py-4">No subtitles added yet</p>
        ) : (
          subtitles.map((subtitle) => (
            <div
              key={subtitle.id}
              className={`p-2 border rounded-md cursor-pointer flex justify-between items-center ${
                selectedSubtitleId === subtitle.id ? "border-blue-500 bg-blue-50" : ""
              }`}
              onClick={() => setSelectedSubtitleId(subtitle.id)}
            >
              <div className="truncate flex-1">
                <div className="text-sm font-medium truncate">{subtitle.text}</div>
                <div className="text-xs text-gray-500">
                  {formatTime(subtitle.startTime)} - {formatTime(subtitle.endTime)}
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={(e) => {
                  e.stopPropagation()
                  dispatch(removeSubtitle(subtitle.id))
                  if (selectedSubtitleId === subtitle.id) {
                    setSelectedSubtitleId(null)
                  }
                }}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          ))
        )}
      </div>

      {/* Subtitle editor */}
      {selectedSubtitle && (
        <div className="space-y-4 border-t pt-4">
          <div className="space-y-2">
            <Label htmlFor="subtitle-text">Text</Label>
            <Input id="subtitle-text" value={selectedSubtitle.text} onChange={handleTextChange} />
          </div>

          <div className="space-y-2">
            <div className="flex justify-between">
              <Label>Timing</Label>
              <div className="text-xs text-gray-500">
                {formatTime(selectedSubtitle.startTime)} - {formatTime(selectedSubtitle.endTime)}
              </div>
            </div>
            <Slider
              min={0}
              max={duration}
              step={0.1}
              value={[selectedSubtitle.startTime, selectedSubtitle.endTime]}
              onValueChange={handleTimingChange}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="font-family">Font</Label>
              <Select
                value={selectedSubtitle.fontFamily}
                onValueChange={(value) => handleStyleChange("fontFamily", value)}
              >
                <SelectTrigger id="font-family">
                  <SelectValue placeholder="Select font" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Arial">Arial</SelectItem>
                  <SelectItem value="Verdana">Verdana</SelectItem>
                  <SelectItem value="Georgia">Georgia</SelectItem>
                  <SelectItem value="Times New Roman">Times New Roman</SelectItem>
                  <SelectItem value="Courier New">Courier New</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="font-size">Size</Label>
              <div className="flex items-center space-x-2">
                <Slider
                  id="font-size"
                  min={12}
                  max={72}
                  step={1}
                  value={[selectedSubtitle.fontSize]}
                  onValueChange={(value) => handleStyleChange("fontSize", value[0])}
                  className="flex-1"
                />
                <span className="text-xs w-8 text-right">{selectedSubtitle.fontSize}px</span>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Color</Label>
            <div className="flex space-x-2">
              {["#FFFFFF", "#000000", "#FF0000", "#00FF00", "#0000FF", "#FFFF00"].map((color) => (
                <div
                  key={color}
                  className={`w-8 h-8 rounded-full cursor-pointer border-2 ${
                    selectedSubtitle.color === color ? "border-blue-500" : "border-transparent"
                  }`}
                  style={{ backgroundColor: color }}
                  onClick={() => handleStyleChange("color", color)}
                />
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label>Alignment</Label>
            <div className="flex space-x-2">
              <Button
                variant={selectedSubtitle.alignment === "left" ? "default" : "outline"}
                size="icon"
                className="h-8 w-8"
                onClick={() => handleStyleChange("alignment", "left")}
              >
                <AlignLeft className="h-4 w-4" />
              </Button>
              <Button
                variant={selectedSubtitle.alignment === "center" ? "default" : "outline"}
                size="icon"
                className="h-8 w-8"
                onClick={() => handleStyleChange("alignment", "center")}
              >
                <AlignCenter className="h-4 w-4" />
              </Button>
              <Button
                variant={selectedSubtitle.alignment === "right" ? "default" : "outline"}
                size="icon"
                className="h-8 w-8"
                onClick={() => handleStyleChange("alignment", "right")}
              >
                <AlignRight className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Position</Label>
            <Select value={selectedSubtitle.position} onValueChange={(value) => handleStyleChange("position", value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select position" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="top">Top</SelectItem>
                <SelectItem value="middle">Middle</SelectItem>
                <SelectItem value="bottom">Bottom</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      )}
    </div>
  )
}
