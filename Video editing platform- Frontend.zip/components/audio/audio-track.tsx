"use client"

import type React from "react"

import { useState } from "react"
import { Upload, Volume2, VolumeX, Plus, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { useAppSelector, useAppDispatch } from "@/lib/redux/hooks"
import { selectAudioTracks, addAudioTrack, updateAudioTrack, removeAudioTrack } from "@/lib/redux/slices/audioSlice"
import { selectProject } from "@/lib/redux/slices/projectSlice"
import { formatTime } from "@/lib/utils/time-format"
import type { AudioTrack as AudioTrackType } from "@/lib/redux/slices/audioSlice"

export default function AudioTrack() {
  const dispatch = useAppDispatch()
  const audioTracks = useAppSelector(selectAudioTracks)
  const { duration } = useAppSelector(selectProject)

  const [selectedTrackId, setSelectedTrackId] = useState<string | null>(null)

  // Find selected track
  const selectedTrack = selectedTrackId ? audioTracks.find((track) => track.id === selectedTrackId) || null : null

  // Handle adding a new audio track
  const handleAddAudioTrack = () => {
    // Mock audio track
    const newTrack: AudioTrackType = {
      id: `audio-${Date.now()}`,
      name: "Background Music",
      url: "/mock-audio.mp3", // Mock URL
      startTime: 0,
      endTime: duration,
      volume: 0.8,
      isMuted: false,
    }

    dispatch(addAudioTrack(newTrack))
    setSelectedTrackId(newTrack.id)
  }

  // Handle file upload
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // Create a local URL for the audio
    const audioUrl = URL.createObjectURL(file)

    const newTrack: AudioTrackType = {
      id: `audio-${Date.now()}`,
      name: file.name,
      url: audioUrl,
      startTime: 0,
      endTime: duration,
      volume: 0.8,
      isMuted: false,
    }

    dispatch(addAudioTrack(newTrack))
    setSelectedTrackId(newTrack.id)
  }

  // Handle updating track name
  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!selectedTrackId) return

    dispatch(
      updateAudioTrack({
        id: selectedTrackId,
        changes: { name: e.target.value },
      }),
    )
  }

  // Handle updating track timing
  const handleTimingChange = (values: number[]) => {
    if (!selectedTrackId) return

    dispatch(
      updateAudioTrack({
        id: selectedTrackId,
        changes: { startTime: values[0], endTime: values[1] },
      }),
    )
  }

  // Handle updating track volume
  const handleVolumeChange = (values: number[]) => {
    if (!selectedTrackId) return

    dispatch(
      updateAudioTrack({
        id: selectedTrackId,
        changes: { volume: values[0] },
      }),
    )
  }

  // Handle toggling mute
  const handleToggleMute = () => {
    if (!selectedTrackId) return

    dispatch(
      updateAudioTrack({
        id: selectedTrackId,
        changes: { isMuted: !selectedTrack?.isMuted },
      }),
    )
  }

  // Handle removing a track
  const handleRemoveTrack = () => {
    if (!selectedTrackId) return

    dispatch(removeAudioTrack(selectedTrackId))
    setSelectedTrackId(null)
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Audio Tracks</h3>
        <div className="flex space-x-2">
          <Button size="sm" onClick={handleAddAudioTrack}>
            <Plus className="h-4 w-4 mr-1" /> Add Track
          </Button>
          <div className="relative">
            <input type="file" id="audio-upload" className="sr-only" accept="audio/*" onChange={handleFileChange} />
            <label htmlFor="audio-upload">
              <Button size="sm" variant="outline" className="cursor-pointer">
                <Upload className="h-4 w-4 mr-1" /> Upload
              </Button>
            </label>
          </div>
        </div>
      </div>

      {/* Audio track list */}
      <div className="space-y-2 max-h-40 overflow-y-auto">
        {audioTracks.length === 0 ? (
          <p className="text-sm text-gray-500 text-center py-4">No audio tracks added yet</p>
        ) : (
          audioTracks.map((track) => (
            <div
              key={track.id}
              className={`p-2 border rounded-md cursor-pointer flex justify-between items-center ${
                selectedTrackId === track.id ? "border-blue-500 bg-blue-50" : ""
              }`}
              onClick={() => setSelectedTrackId(track.id)}
            >
              <div className="truncate flex-1">
                <div className="text-sm font-medium truncate">{track.name}</div>
                <div className="text-xs text-gray-500">
                  {formatTime(track.startTime)} - {formatTime(track.endTime)}
                </div>
              </div>
              <div className="flex items-center">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  onClick={(e) => {
                    e.stopPropagation()
                    if (selectedTrackId === track.id) {
                      dispatch(
                        updateAudioTrack({
                          id: track.id,
                          changes: { isMuted: !track.isMuted },
                        }),
                      )
                    }
                  }}
                >
                  {track.isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  onClick={(e) => {
                    e.stopPropagation()
                    dispatch(removeAudioTrack(track.id))
                    if (selectedTrackId === track.id) {
                      setSelectedTrackId(null)
                    }
                  }}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Audio track editor */}
      {selectedTrack && (
        <div className="space-y-4 border-t pt-4">
          <div className="space-y-2">
            <Label htmlFor="track-name">Name</Label>
            <Input id="track-name" value={selectedTrack.name} onChange={handleNameChange} />
          </div>

          <div className="space-y-2">
            <div className="flex justify-between">
              <Label>Timing</Label>
              <div className="text-xs text-gray-500">
                {formatTime(selectedTrack.startTime)} - {formatTime(selectedTrack.endTime)}
              </div>
            </div>
            <Slider
              min={0}
              max={duration}
              step={0.1}
              value={[selectedTrack.startTime, selectedTrack.endTime]}
              onValueChange={handleTimingChange}
            />
          </div>

          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <Label>Volume</Label>
              <Button variant="ghost" size="icon" className="h-8 w-8" onClick={handleToggleMute}>
                {selectedTrack.isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
              </Button>
            </div>
            <Slider
              min={0}
              max={1}
              step={0.01}
              value={[selectedTrack.volume]}
              onValueChange={handleVolumeChange}
              disabled={selectedTrack.isMuted}
            />
          </div>

          {/* Mock waveform */}
          <div className="h-16 bg-gray-100 rounded-md overflow-hidden">
            <div className="w-full h-full flex items-center justify-center">
              <svg width="100%" height="100%" viewBox="0 0 100 40" preserveAspectRatio="none">
                <path
                  d="M0,20 Q5,5 10,20 T20,20 T30,20 T40,20 T50,20 T60,20 T70,20 T80,20 T90,20 T100,20"
                  fill="none"
                  stroke="#4F46E5"
                  strokeWidth="1"
                />
                <path
                  d="M0,20 Q5,35 10,20 T20,20 T30,20 T40,20 T50,20 T60,20 T70,20 T80,20 T90,20 T100,20"
                  fill="none"
                  stroke="#4F46E5"
                  strokeWidth="1"
                />
              </svg>
            </div>
          </div>

          <div className="flex justify-end">
            <Button variant="destructive" size="sm" onClick={handleRemoveTrack}>
              <Trash2 className="h-4 w-4 mr-1" /> Remove Track
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}
