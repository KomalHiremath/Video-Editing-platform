"use client"

import { useRef, useState } from "react"
import ReactPlayer from "react-player"
import { Play, Pause, Volume2, VolumeX, Maximize } from "lucide-react"
import { Slider } from "@/components/ui/slider"
import { Button } from "@/components/ui/button"
import { useAppSelector, useAppDispatch } from "@/lib/redux/hooks"
import { selectProject, setCurrentTime } from "@/lib/redux/slices/projectSlice"
import { selectSubtitles } from "@/lib/redux/slices/subtitlesSlice"
import { selectOverlays } from "@/lib/redux/slices/overlaysSlice"
import { formatTime } from "@/lib/utils/time-format"

export default function VideoPreview() {
  const dispatch = useAppDispatch()
  const { videoUrl, currentTime, duration, videoSettings } = useAppSelector(selectProject)
  const subtitles = useAppSelector(selectSubtitles)
  const overlays = useAppSelector(selectOverlays)

  const [playing, setPlaying] = useState(false)
  const [volume, setVolume] = useState(0.8)
  const [muted, setMuted] = useState(false)
  const playerRef = useRef<ReactPlayer>(null)
  const containerRef = useRef<HTMLDivElement>(null)

  // Handle time update from player
  const handleProgress = ({ playedSeconds }: { playedSeconds: number }) => {
    dispatch(setCurrentTime(playedSeconds))
  }

  // Handle seeking on slider change
  const handleSeek = (value: number[]) => {
    const newTime = value[0]
    dispatch(setCurrentTime(newTime))
    if (playerRef.current) {
      playerRef.current.seekTo(newTime)
    }
  }

  // Toggle play/pause
  const togglePlay = () => setPlaying(!playing)

  // Toggle mute
  const toggleMute = () => setMuted(!muted)

  // Handle volume change
  const handleVolumeChange = (value: number[]) => {
    setVolume(value[0])
    if (value[0] === 0) {
      setMuted(true)
    } else if (muted) {
      setMuted(false)
    }
  }

  // Handle fullscreen
  const toggleFullscreen = () => {
    if (containerRef.current) {
      if (document.fullscreenElement) {
        document.exitFullscreen()
      } else {
        containerRef.current.requestFullscreen()
      }
    }
  }

  // Find current subtitles to display
  const currentSubtitles = subtitles.filter((sub) => currentTime >= sub.startTime && currentTime <= sub.endTime)

  // Generate filter style based on video settings
  const getFilterStyle = () => {
    const { brightness, contrast, saturation, filter } = videoSettings || {
      brightness: 100,
      contrast: 100,
      saturation: 100,
      filter: "none",
    }

    let filterString = `brightness(${brightness}%) contrast(${contrast}%) saturate(${saturation}%)`

    // Add specific filter effects
    switch (filter) {
      case "sepia":
        filterString += " sepia(100%)"
        break
      case "grayscale":
        filterString += " grayscale(100%)"
        break
      case "bright":
        filterString += " brightness(125%)"
        break
      case "vivid":
        filterString += " contrast(125%)"
        break
      case "cool":
        filterString += " hue-rotate(90deg)"
        break
    }

    return filterString
  }

  // Generate transform style based on video settings
  const getTransformStyle = () => {
    const { rotation, flipHorizontal } = videoSettings || {
      rotation: 0,
      flipHorizontal: false,
    }

    let transform = `rotate(${rotation}deg)`
    if (flipHorizontal) {
      transform += " scaleX(-1)"
    }

    return transform
  }

  return (
    <div className="flex flex-col space-y-2">
      <div ref={containerRef} className="relative aspect-video bg-black rounded-lg overflow-hidden">
        {videoUrl && (
          <>
            <div
              className="w-full h-full"
              style={{
                filter: getFilterStyle(),
                transform: getTransformStyle(),
              }}
            >
              <ReactPlayer
                ref={playerRef}
                url={videoUrl}
                width="100%"
                height="100%"
                playing={playing}
                volume={volume}
                muted={muted}
                onProgress={handleProgress}
                progressInterval={100}
                onDuration={(d) => console.log("Duration:", d)}
              />
            </div>

            {/* Subtitles overlay */}
            <div className="absolute bottom-16 left-0 right-0 flex flex-col items-center">
              {currentSubtitles.map((subtitle) => (
                <div
                  key={subtitle.id}
                  className="bg-black bg-opacity-50 text-white px-4 py-2 rounded-md mb-2 text-center"
                  style={{
                    fontFamily: subtitle.fontFamily || "Arial",
                    fontSize: `${subtitle.fontSize || 24}px`,
                    color: subtitle.color || "white",
                  }}
                >
                  {subtitle.text}
                </div>
              ))}
            </div>

            {/* Image overlays */}
            {overlays.map((overlay) => (
              <div
                key={overlay.id}
                className="absolute"
                style={{
                  top: `${overlay.position.y}%`,
                  left: `${overlay.position.x}%`,
                  width: `${overlay.size.width}px`,
                  height: `${overlay.size.height}px`,
                  opacity: overlay.opacity,
                  transform: `rotate(${overlay.rotation || 0}deg)`,
                  border: overlay.border
                    ? `${overlay.border.width}px ${overlay.border.style} ${overlay.border.color}`
                    : "none",
                }}
              >
                <img
                  src={overlay.url || "/placeholder.svg"}
                  alt={overlay.name}
                  className="w-full h-full object-contain"
                />
              </div>
            ))}
          </>
        )}
      </div>

      {/* Video controls */}
      <div className="flex flex-col space-y-2">
        <div className="flex items-center space-x-2">
          <Button variant="ghost" size="icon" onClick={togglePlay}>
            {playing ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
          </Button>
          <div className="text-sm font-medium">
            {formatTime(currentTime)} / {formatTime(duration)}
          </div>
          <div className="flex-1 mx-2">
            <Slider value={[currentTime]} min={0} max={duration || 100} step={0.1} onValueChange={handleSeek} />
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="icon" onClick={toggleMute}>
              {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
            </Button>
            <div className="w-20">
              <Slider value={[muted ? 0 : volume]} min={0} max={1} step={0.01} onValueChange={handleVolumeChange} />
            </div>
            <Button variant="ghost" size="icon" onClick={toggleFullscreen}>
              <Maximize className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
