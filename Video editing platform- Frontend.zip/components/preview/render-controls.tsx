"use client"

import { useState } from "react"
import { Download, Film, Loader2, Save } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Progress } from "@/components/ui/progress"
import { useToast } from "@/components/ui/use-toast"
import { useAppSelector, useAppDispatch } from "@/lib/redux/hooks"
import { selectProject } from "@/lib/redux/slices/projectSlice"
import { selectScenes } from "@/lib/redux/slices/timelineSlice"
import { selectSubtitles } from "@/lib/redux/slices/subtitlesSlice"
import { selectAudioTracks } from "@/lib/redux/slices/audioSlice"
import { selectOverlays } from "@/lib/redux/slices/overlaysSlice"
import { mockRenderVideo } from "@/lib/utils/mock-api"

export default function RenderControls() {
  const dispatch = useAppDispatch()
  const { videoUrl, videoSettings } = useAppSelector(selectProject)
  const scenes = useAppSelector(selectScenes)
  const subtitles = useAppSelector(selectSubtitles)
  const audioTracks = useAppSelector(selectAudioTracks)
  const overlays = useAppSelector(selectOverlays)
  const { toast } = useToast()

  const [isRendering, setIsRendering] = useState(false)
  const [renderProgress, setRenderProgress] = useState(0)
  const [renderComplete, setRenderComplete] = useState(false)
  const [renderedVideoUrl, setRenderedVideoUrl] = useState<string | null>(null)
  const [renderFormat, setRenderFormat] = useState("mp4")
  const [renderQuality, setRenderQuality] = useState("high")
  const [projectName, setProjectName] = useState("My Video Project")

  // Handle render button click
  const handleRender = async () => {
    if (!videoUrl || isRendering) return

    setIsRendering(true)
    setRenderProgress(0)
    setRenderComplete(false)

    try {
      // Prepare render configuration
      const renderConfig = {
        format: renderFormat,
        quality: renderQuality,
        scenes: scenes,
        subtitles: subtitles,
        audioTracks: audioTracks,
        overlays: overlays,
        videoSettings: videoSettings,
      }

      // Log the render configuration (in a real app, this would be sent to the backend)
      console.log("Rendering with configuration:", renderConfig)

      // Mock rendering process
      const result = await mockRenderVideo((progress) => {
        setRenderProgress(progress)
      })

      // In a real app, the backend would return the URL to the rendered video
      setRenderedVideoUrl(videoUrl) // Using original video URL as a placeholder
      setRenderComplete(true)

      toast({
        title: "Rendering complete",
        description: "Your video has been successfully rendered.",
      })
    } catch (error) {
      toast({
        title: "Rendering failed",
        description: "There was an error rendering your video.",
        variant: "destructive",
      })
    } finally {
      setIsRendering(false)
    }
  }

  // Handle download button click
  const handleDownload = () => {
    if (!renderedVideoUrl) return

    // Create a download link for the rendered video
    const a = document.createElement("a")
    a.href = renderedVideoUrl
    a.download = `${projectName.replace(/\s+/g, "_")}.${renderFormat}`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)

    toast({
      title: "Download started",
      description: `Your video is being downloaded as ${projectName.replace(/\s+/g, "_")}.${renderFormat}`,
    })
  }

  // Handle save project button click
  const handleSaveProject = () => {
    // In a real app, this would save the project state to a backend
    const projectData = {
      name: projectName,
      scenes: scenes,
      subtitles: subtitles,
      audioTracks: audioTracks,
      overlays: overlays,
      videoSettings: videoSettings,
    }

    // Log the project data (in a real app, this would be sent to the backend)
    console.log("Saving project:", projectData)

    // Save to localStorage as a demo
    localStorage.setItem("videoEditorProject", JSON.stringify(projectData))

    toast({
      title: "Project saved",
      description: `Project "${projectName}" has been saved.`,
    })
  }

  return (
    <div className="border rounded-lg p-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h3 className="text-lg font-semibold">Export Video</h3>
          <p className="text-sm text-gray-500">Render and download your edited video</p>
        </div>

        <div className="flex flex-col sm:flex-row gap-2 w-full md:w-auto">
          <div className="grid grid-cols-2 gap-2 w-full sm:w-auto">
            <div>
              <Select value={renderFormat} onValueChange={setRenderFormat}>
                <SelectTrigger>
                  <SelectValue placeholder="Format" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="mp4">MP4</SelectItem>
                  <SelectItem value="webm">WebM</SelectItem>
                  <SelectItem value="mov">MOV</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Select value={renderQuality} onValueChange={setRenderQuality}>
                <SelectTrigger>
                  <SelectValue placeholder="Quality" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low (480p)</SelectItem>
                  <SelectItem value="medium">Medium (720p)</SelectItem>
                  <SelectItem value="high">High (1080p)</SelectItem>
                  <SelectItem value="ultra">Ultra (4K)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex gap-2">
            <Button onClick={handleSaveProject} variant="outline" disabled={!videoUrl} className="w-full sm:w-auto">
              <Save className="h-4 w-4 mr-1" /> Save
            </Button>

            <Button onClick={handleRender} disabled={isRendering || !videoUrl} className="w-full sm:w-auto">
              {isRendering ? (
                <>
                  <Loader2 className="h-4 w-4 mr-1 animate-spin" /> Rendering...
                </>
              ) : (
                <>
                  <Film className="h-4 w-4 mr-1" /> Render
                </>
              )}
            </Button>

            <Button
              onClick={handleDownload}
              disabled={!renderComplete || isRendering}
              variant={renderComplete ? "default" : "outline"}
              className="w-full sm:w-auto"
            >
              <Download className="h-4 w-4 mr-1" /> Download
            </Button>
          </div>
        </div>
      </div>

      {isRendering && (
        <div className="mt-4 space-y-2">
          <Progress value={renderProgress} />
          <p className="text-xs text-center text-gray-500">Rendering: {Math.round(renderProgress)}% complete</p>
        </div>
      )}
    </div>
  )
}
