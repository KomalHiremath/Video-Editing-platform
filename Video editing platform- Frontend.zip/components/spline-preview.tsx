"use client"

import { useState, useEffect } from "react"
import { Progress } from "@/components/ui/progress"
import dynamic from "next/dynamic"
import { Video } from "lucide-react"

// Import Spline component with no SSR
const Spline = dynamic(() => import("@splinetool/react-spline").then((mod) => mod.default), {
  ssr: false,
  loading: () => null,
})

export default function SplinePreview() {
  const [isLoading, setIsLoading] = useState(true)
  const [loadingProgress, setLoadingProgress] = useState(0)
  const [loadError, setLoadError] = useState(false)

  // Handle loading state with progress
  useEffect(() => {
    const interval = setInterval(() => {
      setLoadingProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setTimeout(() => setIsLoading(false), 500)
          return 100
        }
        return prev + 5
      })
    }, 100)

    return () => clearInterval(interval)
  }, [])

  const handleSplineError = () => {
    setLoadError(true)
    setIsLoading(false)
  }

  return (
    <div className="w-full h-full">
      {isLoading && (
        <div className="w-full h-full flex flex-col items-center justify-center">
          <div className="w-48 mb-4">
            <Progress value={loadingProgress} className="h-3" />
          </div>
          <p className="text-sm">{loadingProgress}% Loading Preview</p>
        </div>
      )}

      {!isLoading && (
        <div className="w-full h-full">
          {loadError ? (
            <div className="w-full h-full flex flex-col items-center justify-center bg-gray-100 dark:bg-gray-800">
              <Video className="h-16 w-16 text-gray-400 mb-4" />
              <p className="text-gray-500">Video Editor Preview</p>
            </div>
          ) : (
            <div className="w-full h-full">
              <Spline
                scene="https://prod.spline.design/6Wq1Q7YGyM-iab9i/scene.splinecode"
                onError={handleSplineError}
              />
            </div>
          )}
        </div>
      )}
    </div>
  )
}
