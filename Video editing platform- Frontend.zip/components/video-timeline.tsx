"use client"

import type React from "react"

import { useRef } from "react"

interface VideoTimelineProps {
  duration: number
  currentTime: number
  trimStart: number
  trimEnd: number
  onSeek: (time: number) => void
}

export default function VideoTimeline({ duration, currentTime, trimStart, trimEnd, onSeek }: VideoTimelineProps) {
  const timelineRef = useRef<HTMLDivElement>(null)

  const handleClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (timelineRef.current) {
      const rect = timelineRef.current.getBoundingClientRect()
      const position = (e.clientX - rect.left) / rect.width
      const newTime = position * duration
      onSeek(newTime)
    }
  }

  return (
    <div ref={timelineRef} className="relative h-8 bg-gray-200 rounded cursor-pointer" onClick={handleClick}>
      {/* Trim area */}
      <div
        className="absolute h-full bg-blue-100"
        style={{
          left: `${(trimStart / duration) * 100}%`,
          width: `${((trimEnd - trimStart) / duration) * 100}%`,
        }}
      />

      {/* Current time indicator */}
      <div className="absolute h-full w-0.5 bg-red-500 z-10" style={{ left: `${(currentTime / duration) * 100}%` }} />

      {/* Time markers */}
      <div className="absolute top-0 left-0 w-full h-full flex">
        {Array.from({ length: 10 }).map((_, i) => (
          <div key={i} className="flex-1 border-l border-gray-400 h-2 mt-auto">
            <div className="text-xs text-gray-500 mt-2">{formatTime((duration / 10) * i)}</div>
          </div>
        ))}
      </div>
    </div>
  )
}

function formatTime(seconds: number) {
  const mins = Math.floor(seconds / 60)
  const secs = Math.floor(seconds % 60)
  return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
}
