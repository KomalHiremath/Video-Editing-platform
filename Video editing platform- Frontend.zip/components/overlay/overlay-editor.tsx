"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Upload, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useAppSelector, useAppDispatch } from "@/lib/redux/hooks"
import { selectOverlays, addOverlay, updateOverlay, removeOverlay } from "@/lib/redux/slices/overlaysSlice"
import type { ImageOverlay } from "@/lib/types"

export default function OverlayEditor() {
  const dispatch = useAppDispatch()
  const overlays = useAppSelector(selectOverlays)

  const [selectedOverlayId, setSelectedOverlayId] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  // Find selected overlay
  const selectedOverlay = selectedOverlayId
    ? overlays.find((overlay) => overlay.id === selectedOverlayId) || null
    : null

  // Handle file upload
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // Create a local URL for the image
    const imageUrl = URL.createObjectURL(file)

    const newOverlay: ImageOverlay = {
      id: `overlay-${Date.now()}`,
      type: "image",
      name: file.name,
      url: imageUrl,
      position: { x: 50, y: 50 }, // Center of the screen
      size: { width: 200, height: 200 },
      opacity: 1,
      rotation: 0,
      border: null,
    }

    dispatch(addOverlay(newOverlay))
    setSelectedOverlayId(newOverlay.id)
  }

  // Handle updating overlay name
  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!selectedOverlayId) return

    dispatch(
      updateOverlay({
        id: selectedOverlayId,
        changes: { name: e.target.value },
      }),
    )
  }

  // Handle updating overlay position
  const handlePositionChange = (axis: "x" | "y", value: number[]) => {
    if (!selectedOverlayId || !selectedOverlay) return

    dispatch(
      updateOverlay({
        id: selectedOverlayId,
        changes: {
          position: {
            ...selectedOverlay.position,
            [axis]: value[0],
          },
        },
      }),
    )
  }

  // Handle updating overlay size
  const handleSizeChange = (dimension: "width" | "height", value: number[]) => {
    if (!selectedOverlayId || !selectedOverlay) return

    dispatch(
      updateOverlay({
        id: selectedOverlayId,
        changes: {
          size: {
            ...selectedOverlay.size,
            [dimension]: value[0],
          },
        },
      }),
    )
  }

  // Handle updating overlay opacity
  const handleOpacityChange = (value: number[]) => {
    if (!selectedOverlayId) return

    dispatch(
      updateOverlay({
        id: selectedOverlayId,
        changes: { opacity: value[0] },
      }),
    )
  }

  // Handle updating overlay rotation
  const handleRotationChange = (value: number[]) => {
    if (!selectedOverlayId) return

    dispatch(
      updateOverlay({
        id: selectedOverlayId,
        changes: { rotation: value[0] },
      }),
    )
  }

  // Handle updating overlay border
  const handleBorderChange = (property: string, value: any) => {
    if (!selectedOverlayId || !selectedOverlay) return

    const currentBorder = selectedOverlay.border || { width: 2, style: "solid", color: "#000000" }

    dispatch(
      updateOverlay({
        id: selectedOverlayId,
        changes: {
          border: {
            ...currentBorder,
            [property]: value,
          },
        },
      }),
    )
  }

  // Handle removing border
  const handleRemoveBorder = () => {
    if (!selectedOverlayId) return

    dispatch(
      updateOverlay({
        id: selectedOverlayId,
        changes: { border: null },
      }),
    )
  }

  // Handle removing an overlay
  const handleRemoveOverlay = () => {
    if (!selectedOverlayId) return

    dispatch(removeOverlay(selectedOverlayId))
    setSelectedOverlayId(null)
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Image Overlays</h3>
        <div className="relative">
          <input type="file" ref={fileInputRef} className="sr-only" accept="image/*" onChange={handleFileChange} />
          <Button size="sm" onClick={() => fileInputRef.current?.click()}>
            <Upload className="h-4 w-4 mr-1" /> Upload Image
          </Button>
        </div>
      </div>

      {/* Overlay list */}
      <div className="space-y-2 max-h-40 overflow-y-auto">
        {overlays.length === 0 ? (
          <p className="text-sm text-gray-500 text-center py-4">No image overlays added yet</p>
        ) : (
          overlays.map((overlay) => (
            <div
              key={overlay.id}
              className={`p-2 border rounded-md cursor-pointer flex items-center ${
                selectedOverlayId === overlay.id ? "border-blue-500 bg-blue-50" : ""
              }`}
              onClick={() => setSelectedOverlayId(overlay.id)}
            >
              <div className="h-10 w-10 bg-gray-100 rounded mr-2 overflow-hidden">
                <img
                  src={overlay.url || "/placeholder.svg"}
                  alt={overlay.name}
                  className="h-full w-full object-cover"
                />
              </div>
              <div className="truncate flex-1">
                <div className="text-sm font-medium truncate">{overlay.name}</div>
                <div className="text-xs text-gray-500">
                  {overlay.size.width}x{overlay.size.height}
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={(e) => {
                  e.stopPropagation()
                  dispatch(removeOverlay(overlay.id))
                  if (selectedOverlayId === overlay.id) {
                    setSelectedOverlayId(null)
                  }
                }}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          ))
        )}
      </div>

      {/* Overlay editor */}
      {selectedOverlay && (
        <div className="space-y-4 border-t pt-4">
          <div className="space-y-2">
            <Label htmlFor="overlay-name">Name</Label>
            <Input id="overlay-name" value={selectedOverlay.name} onChange={handleNameChange} />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <div className="flex justify-between">
                <Label>Position X</Label>
                <span className="text-xs text-gray-500">{selectedOverlay.position.x}%</span>
              </div>
              <Slider
                min={0}
                max={100}
                step={1}
                value={[selectedOverlay.position.x]}
                onValueChange={(value) => handlePositionChange("x", value)}
              />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between">
                <Label>Position Y</Label>
                <span className="text-xs text-gray-500">{selectedOverlay.position.y}%</span>
              </div>
              <Slider
                min={0}
                max={100}
                step={1}
                value={[selectedOverlay.position.y]}
                onValueChange={(value) => handlePositionChange("y", value)}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <div className="flex justify-between">
                <Label>Width</Label>
                <span className="text-xs text-gray-500">{selectedOverlay.size.width}px</span>
              </div>
              <Slider
                min={50}
                max={800}
                step={1}
                value={[selectedOverlay.size.width]}
                onValueChange={(value) => handleSizeChange("width", value)}
              />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between">
                <Label>Height</Label>
                <span className="text-xs text-gray-500">{selectedOverlay.size.height}px</span>
              </div>
              <Slider
                min={50}
                max={800}
                step={1}
                value={[selectedOverlay.size.height]}
                onValueChange={(value) => handleSizeChange("height", value)}
              />
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between">
              <Label>Opacity</Label>
              <span className="text-xs text-gray-500">{Math.round(selectedOverlay.opacity * 100)}%</span>
            </div>
            <Slider min={0} max={1} step={0.01} value={[selectedOverlay.opacity]} onValueChange={handleOpacityChange} />
          </div>

          <div className="space-y-2">
            <div className="flex justify-between">
              <Label>Rotation</Label>
              <span className="text-xs text-gray-500">{selectedOverlay.rotation}°</span>
            </div>
            <Slider
              min={0}
              max={360}
              step={1}
              value={[selectedOverlay.rotation]}
              onValueChange={handleRotationChange}
            />
          </div>

          <div className="space-y-2">
            <Label>Border</Label>
            {selectedOverlay.border ? (
              <div className="space-y-4">
                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <Label className="text-xs">Width</Label>
                    <Select
                      value={selectedOverlay.border.width.toString()}
                      onValueChange={(value) => handleBorderChange("width", Number.parseInt(value))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Width" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1px</SelectItem>
                        <SelectItem value="2">2px</SelectItem>
                        <SelectItem value="3">3px</SelectItem>
                        <SelectItem value="4">4px</SelectItem>
                        <SelectItem value="5">5px</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label className="text-xs">Style</Label>
                    <Select
                      value={selectedOverlay.border.style}
                      onValueChange={(value) => handleBorderChange("style", value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Style" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="solid">Solid</SelectItem>
                        <SelectItem value="dashed">Dashed</SelectItem>
                        <SelectItem value="dotted">Dotted</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label className="text-xs">Color</Label>
                    <div className="flex space-x-1 mt-2">
                      {["#000000", "#FFFFFF", "#FF0000", "#00FF00", "#0000FF"].map((color) => (
                        <div
                          key={color}
                          className={`w-6 h-6 rounded cursor-pointer border ${
                            selectedOverlay.border?.color === color ? "ring-2 ring-blue-500" : ""
                          }`}
                          style={{ backgroundColor: color }}
                          onClick={() => handleBorderChange("color", color)}
                        />
                      ))}
                    </div>
                  </div>
                </div>

                <Button variant="outline" size="sm" onClick={handleRemoveBorder}>
                  Remove Border
                </Button>
              </div>
            ) : (
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleBorderChange("", { width: 2, style: "solid", color: "#000000" })}
              >
                Add Border
              </Button>
            )}
          </div>

          <div className="flex justify-end">
            <Button variant="destructive" size="sm" onClick={handleRemoveOverlay}>
              <Trash2 className="h-4 w-4 mr-1" /> Remove Overlay
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}
