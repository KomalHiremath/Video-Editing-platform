"use client"
import { Provider } from "react-redux"
import { store } from "@/lib/redux/store"
import EditorLayout from "@/components/layout/editor-layout"
import VideoUpload from "@/components/upload/video-upload"
import Timeline from "@/components/timeline/timeline"
import VideoPreview from "@/components/preview/video-preview"
import ControlPanel from "@/components/control-panel/control-panel"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import SubtitleEditor from "@/components/subtitles/subtitle-editor"
import AudioTrack from "@/components/audio/audio-track"
import OverlayEditor from "@/components/overlay/overlay-editor"
import RenderControls from "@/components/preview/render-controls"
import { useAppSelector } from "@/lib/redux/hooks"
import { selectProject } from "@/lib/redux/slices/projectSlice"

function Editor() {
  const project = useAppSelector(selectProject)

  return (
    <EditorLayout>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 h-full">
        <div className="lg:col-span-2 flex flex-col gap-4">
          {!project.videoUrl ? (
            <VideoUpload />
          ) : (
            <>
              <VideoPreview />
              <Timeline />
              <RenderControls />
            </>
          )}
        </div>
        <div className="lg:col-span-1">
          {project.videoUrl && (
            <Tabs defaultValue="controls" className="w-full">
              <TabsList className="grid grid-cols-4 mb-4">
                <TabsTrigger value="controls">Controls</TabsTrigger>
                <TabsTrigger value="text">Text</TabsTrigger>
                <TabsTrigger value="audio">Audio</TabsTrigger>
                <TabsTrigger value="overlay">Overlay</TabsTrigger>
              </TabsList>
              <TabsContent value="controls" className="space-y-4">
                <ControlPanel />
              </TabsContent>
              <TabsContent value="text" className="space-y-4">
                <SubtitleEditor />
              </TabsContent>
              <TabsContent value="audio" className="space-y-4">
                <AudioTrack />
              </TabsContent>
              <TabsContent value="overlay" className="space-y-4">
                <OverlayEditor />
              </TabsContent>
            </Tabs>
          )}
        </div>
      </div>
    </EditorLayout>
  )
}

export default function EditorPage() {
  return (
    <Provider store={store}>
      <Editor />
    </Provider>
  )
}
