import HomeClient from "@/components/home-client"
import HomeWrapper from "@/components/home-wrapper"

export default function HomePage() {
  return (
    <HomeWrapper>
      <HomeClient />
    </HomeWrapper>
  )
}
