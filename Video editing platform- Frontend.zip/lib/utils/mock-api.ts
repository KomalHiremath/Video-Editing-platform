// Mock API functions for simulating backend operations

/**
 * Simulates uploading a video file with progress updates
 */
export async function mockUploadVideo(
  file: File,
  onProgress: (progress: number) => void,
): Promise<{ url: string; progress: number }> {
  // Simulate upload progress
  let progress = 0
  const totalSteps = 10

  for (let i = 0; i < totalSteps; i++) {
    await new Promise((resolve) => setTimeout(resolve, 300))
    progress = Math.min(100, (i + 1) * (100 / totalSteps))
    onProgress(progress)
  }

  return {
    url: URL.createObjectURL(file),
    progress: 100,
  }
}

/**
 * Simulates rendering a video with progress updates
 */
export async function mockRenderVideo(
  onProgress: (progress: number) => void,
): Promise<{ url: string; progress: number }> {
  // Simulate rendering progress with variable speeds to make it more realistic
  let progress = 0
  const totalSteps = 20

  // Simulate different phases of rendering
  // Phase 1: Initial processing (slower)
  for (let i = 0; i < 5; i++) {
    await new Promise((resolve) => setTimeout(resolve, 300))
    progress = Math.min(100, (i + 1) * (20 / 5))
    onProgress(progress)
  }

  // Phase 2: Main rendering (faster)
  for (let i = 0; i < 10; i++) {
    await new Promise((resolve) => setTimeout(resolve, 200))
    progress = Math.min(100, 20 + (i + 1) * (60 / 10))
    onProgress(progress)
  }

  // Phase 3: Finalizing (slower again)
  for (let i = 0; i < 5; i++) {
    await new Promise((resolve) => setTimeout(resolve, 250))
    progress = Math.min(100, 80 + (i + 1) * (20 / 5))
    onProgress(progress)
  }

  return {
    url: "mock-rendered-video.mp4",
    progress: 100,
  }
}

/**
 * Simulates loading a saved project
 */
export async function mockLoadProject(projectId: string): Promise<any> {
  // In a real app, this would fetch from a backend
  await new Promise((resolve) => setTimeout(resolve, 800))

  // Try to load from localStorage as a demo
  const savedProject = localStorage.getItem("videoEditorProject")

  if (savedProject) {
    return JSON.parse(savedProject)
  }

  // Return a mock project if nothing is saved
  return {
    name: "Demo Project",
    scenes: [],
    subtitles: [],
    audioTracks: [],
    overlays: [],
    videoSettings: {
      brightness: 100,
      contrast: 100,
      saturation: 100,
      rotation: 0,
      flipHorizontal: false,
      filter: "none",
    },
  }
}
