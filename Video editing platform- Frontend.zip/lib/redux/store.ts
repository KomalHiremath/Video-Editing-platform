import { configureStore } from "@reduxjs/toolkit"
import projectReducer from "./slices/projectSlice"
import timelineReducer from "./slices/timelineSlice"
import subtitlesReducer from "./slices/subtitlesSlice"
import audioReducer from "./slices/audioSlice"
import overlaysReducer from "./slices/overlaysSlice"

export const store = configureStore({
  reducer: {
    project: projectReducer,
    timeline: timelineReducer,
    subtitles: subtitlesReducer,
    audio: audioReducer,
    overlays: overlaysReducer,
  },
})

export type RootState = ReturnType<typeof store.getState>
export type AppDispatch = typeof store.dispatch
