import { createSlice, type PayloadAction } from "@reduxjs/toolkit"
import type { RootState } from "../store"

interface Subtitle {
  id: string
  text: string
  start: number
  end: number
}

interface SubtitlesState {
  subtitles: Subtitle[]
}

const initialState: SubtitlesState = {
  subtitles: [],
}

export const subtitlesSlice = createSlice({
  name: "subtitles",
  initialState,
  reducers: {
    addSubtitle: (state, action: PayloadAction<Subtitle>) => {
      state.subtitles.push(action.payload)
    },
    updateSubtitle: (state, action: PayloadAction<{ id: string; changes: Partial<Subtitle> }>) => {
      const { id, changes } = action.payload
      const subtitleIndex = state.subtitles.findIndex((subtitle) => subtitle.id === id)
      if (subtitleIndex !== -1) {
        state.subtitles[subtitleIndex] = { ...state.subtitles[subtitleIndex], ...changes }
      }
    },
    removeSubtitle: (state, action: PayloadAction<string>) => {
      state.subtitles = state.subtitles.filter((subtitle) => subtitle.id !== action.payload)
    },
  },
})

export const { addSubtitle, updateSubtitle, removeSubtitle } = subtitlesSlice.actions

export const selectSubtitles = (state: RootState) => state.subtitles.subtitles

export default subtitlesSlice.reducer
