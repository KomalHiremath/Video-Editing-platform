import { createSlice, type PayloadAction } from "@reduxjs/toolkit"
import type { RootState } from "../store"

interface ImageOverlay {
  id: string
  [key: string]: any // allows ImageOverlay to have dynamic properties
}

interface OverlaysState {
  overlays: ImageOverlay[]
}

const initialState: OverlaysState = {
  overlays: [],
}

export const overlaysSlice = createSlice({
  name: "overlays",
  initialState,
  reducers: {
    addOverlay: (state, action: PayloadAction<ImageOverlay>) => {
      state.overlays.push(action.payload)
    },
    updateOverlay: (state, action: PayloadAction<{ id: string; changes: Partial<ImageOverlay> }>) => {
      const { id, changes } = action.payload
      const overlayIndex = state.overlays.findIndex((overlay) => overlay.id === id)
      if (overlayIndex !== -1) {
        state.overlays[overlayIndex] = { ...state.overlays[overlayIndex], ...changes }
      }
    },
    removeOverlay: (state, action: PayloadAction<string>) => {
      state.overlays = state.overlays.filter((overlay) => overlay.id !== action.payload)
    },
  },
})

export const { addOverlay, updateOverlay, removeOverlay } = overlaysSlice.actions

export const selectOverlays = (state: RootState) => state.overlays.overlays

export default overlaysSlice.reducer
