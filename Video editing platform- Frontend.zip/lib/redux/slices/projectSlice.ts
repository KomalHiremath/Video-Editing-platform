import { createSlice, type PayloadAction } from "@reduxjs/toolkit"
import type { RootState } from "../store"

interface VideoSettings {
  brightness: number
  contrast: number
  saturation: number
  rotation: number
  flipHorizontal: boolean
  filter: string
}

interface ProjectState {
  videoUrl: string | null
  currentTime: number
  duration: number
  videoSettings: VideoSettings
}

const initialState: ProjectState = {
  videoUrl: null,
  currentTime: 0,
  duration: 0,
  videoSettings: {
    brightness: 100,
    contrast: 100,
    saturation: 100,
    rotation: 0,
    flipHorizontal: false,
    filter: "none",
  },
}

export const projectSlice = createSlice({
  name: "project",
  initialState,
  reducers: {
    setVideoUrl: (state, action: PayloadAction<string>) => {
      state.videoUrl = action.payload
    },
    setCurrentTime: (state, action: PayloadAction<number>) => {
      state.currentTime = action.payload
    },
    setVideoDuration: (state, action: PayloadAction<number>) => {
      state.duration = action.payload
    },
    updateVideoSettings: (state, action: PayloadAction<Partial<VideoSettings>>) => {
      state.videoSettings = { ...state.videoSettings, ...action.payload }
    },
    applyFilter: (state, action: PayloadAction<string>) => {
      state.videoSettings.filter = action.payload

      // Reset other settings when applying a filter
      if (action.payload !== "none") {
        // Apply preset values based on filter type
        switch (action.payload) {
          case "sepia":
            state.videoSettings.brightness = 105
            state.videoSettings.contrast = 110
            state.videoSettings.saturation = 90
            break
          case "grayscale":
            state.videoSettings.brightness = 100
            state.videoSettings.contrast = 110
            state.videoSettings.saturation = 0
            break
          case "bright":
            state.videoSettings.brightness = 125
            state.videoSettings.contrast = 100
            state.videoSettings.saturation = 110
            break
          case "vivid":
            state.videoSettings.brightness = 105
            state.videoSettings.contrast = 125
            state.videoSettings.saturation = 130
            break
          case "cool":
            state.videoSettings.brightness = 100
            state.videoSettings.contrast = 100
            state.videoSettings.saturation = 110
            break
        }
      } else {
        // Reset to default values
        state.videoSettings.brightness = 100
        state.videoSettings.contrast = 100
        state.videoSettings.saturation = 100
      }
    },
    resetVideoSettings: (state) => {
      state.videoSettings = {
        brightness: 100,
        contrast: 100,
        saturation: 100,
        rotation: 0,
        flipHorizontal: false,
        filter: "none",
      }
    },
  },
})

export const { setVideoUrl, setCurrentTime, setVideoDuration, updateVideoSettings, applyFilter, resetVideoSettings } =
  projectSlice.actions

export const selectProject = (state: RootState) => state.project

export default projectSlice.reducer
