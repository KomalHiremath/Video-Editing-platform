import { createSlice, type PayloadAction } from "@reduxjs/toolkit"
import type { RootState } from "../store"

interface AudioTrack {
  id: string
  url: string
  title: string
  artist: string
}

interface AudioState {
  audioTracks: AudioTrack[]
}

const initialState: AudioState = {
  audioTracks: [],
}

export const audioSlice = createSlice({
  name: "audio",
  initialState,
  reducers: {
    addAudioTrack: (state, action: PayloadAction<AudioTrack>) => {
      state.audioTracks.push(action.payload)
    },
    updateAudioTrack: (state, action: PayloadAction<{ id: string; changes: Partial<AudioTrack> }>) => {
      const { id, changes } = action.payload
      const trackIndex = state.audioTracks.findIndex((track) => track.id === id)
      if (trackIndex !== -1) {
        state.audioTracks[trackIndex] = { ...state.audioTracks[trackIndex], ...changes }
      }
    },
    removeAudioTrack: (state, action: PayloadAction<string>) => {
      state.audioTracks = state.audioTracks.filter((track) => track.id !== action.payload)
    },
  },
})

export const { addAudioTrack, updateAudioTrack, removeAudioTrack } = audioSlice.actions

export const selectAudioTracks = (state: RootState) => state.audio.audioTracks

export default audioSlice.reducer
