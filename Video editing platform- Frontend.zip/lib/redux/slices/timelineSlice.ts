import { createSlice, type PayloadAction } from "@reduxjs/toolkit"
import type { RootState } from "../store"

interface Scene {
  id: string
  startTime: number
  endTime: number
  name: string
}

interface TimelineState {
  scenes: Scene[]
}

const initialState: TimelineState = {
  scenes: [],
}

export const timelineSlice = createSlice({
  name: "timeline",
  initialState,
  reducers: {
    addScenes: (state, action: PayloadAction<Scene[]>) => {
      state.scenes.push(...action.payload)
    },
    updateScene: (state, action: PayloadAction<{ id: string; changes: Partial<Scene> }>) => {
      const { id, changes } = action.payload
      const sceneIndex = state.scenes.findIndex((scene) => scene.id === id)
      if (sceneIndex !== -1) {
        state.scenes[sceneIndex] = { ...state.scenes[sceneIndex], ...changes }
      }
    },
    removeScene: (state, action: PayloadAction<string>) => {
      state.scenes = state.scenes.filter((scene) => scene.id !== action.payload)
    },
    reorderScenes: (state, action: PayloadAction<{ dragIndex: number; hoverIndex: number }>) => {
      const { dragIndex, hoverIndex } = action.payload
      const draggedScene = state.scenes[dragIndex]
      state.scenes.splice(dragIndex, 1)
      state.scenes.splice(hoverIndex, 0, draggedScene)
    },
    splitSceneAtTime: (state, action: PayloadAction<{ sceneId: string; splitTime: number }>) => {
      const { sceneId, splitTime } = action.payload
      const sceneIndex = state.scenes.findIndex((scene) => scene.id === sceneId)

      if (sceneIndex !== -1) {
        const originalScene = state.scenes[sceneIndex]

        // Only split if the time is within the scene bounds
        if (splitTime > originalScene.startTime && splitTime < originalScene.endTime) {
          // Update the original scene to end at the split point
          state.scenes[sceneIndex] = {
            ...originalScene,
            endTime: splitTime,
          }

          // Create a new scene starting at the split point
          const newScene = {
            id: `scene-${Date.now()}`,
            startTime: splitTime,
            endTime: originalScene.endTime,
            name: `${originalScene.name} (Split)`,
          }

          // Insert the new scene after the original
          state.scenes.splice(sceneIndex + 1, 0, newScene)
        }
      }
    },
  },
})

export const { addScenes, updateScene, removeScene, reorderScenes, splitSceneAtTime } = timelineSlice.actions

export const selectScenes = (state: RootState) => state.timeline.scenes

export default timelineSlice.reducer
